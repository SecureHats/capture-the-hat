# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

function Send-Result {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        $Value
    )

    # Associate values to output bindings by calling 'Push-OutputBinding'.
    Push-OutputBinding `
        -Name Response `
        -Value ([HttpResponseContext]@{ Body = $Value })
}

$regEx_Guid = '^[{]?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}[}]?$'

$query = $Request.RawBody
$workspaceId = $Request.Query.WorkspaceId

if ($null -eq $workspaceId) {
    Send-Result -Value 'No workspaceId was provided'
    exit
}
if (-not($workspaceId -match $regEx_Guid)) {
    Send-Result -Value 'The workspaceId was not a valid Guid'
    exit
}

if ($null -eq $query) {
    Send-Result -Value 'No valid KQL query was'
}

$apiResult = (Invoke-AzOperationalInsightsQuery -WorkspaceId $($workspaceId) -Query "$($query)").Results | ConvertTo-Json -AsArray

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        Body = $apiResult
    })
